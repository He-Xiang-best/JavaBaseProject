package com.linglifu;

import com.linglifu.frame.SelectorFrame;

public class Main {
	public static void main(String[] args) {
		new SelectorFrame();
	}
}
