package com.linglifu.enumtype;

public interface Question {
	public static final String[] QUESTIONS= new String[] {
		"你父亲的名字",
		"你母亲的名字",
		"你的小学老师叫什么",
		"我第一个喜欢的人",
		"我的第一辆车型号"
	};
}
