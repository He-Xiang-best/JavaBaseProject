package com.linglifu.util;

public class StringUtil {
	public static boolean isNull(String str) {
		return str == null || "".equals(str) ? true : false;
	}
}
