# notebook
Java语言开发的一个简易版的日记本
