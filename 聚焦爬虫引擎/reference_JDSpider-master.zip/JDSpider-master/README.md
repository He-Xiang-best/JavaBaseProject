# JDSpider
基于Jsoup的多线程java爬虫应用，爬取京东网商品信息并存入数据库

![存入数据库](http://img.blog.csdn.net/20170328123017956?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvbHNmOTIxMDE2/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
