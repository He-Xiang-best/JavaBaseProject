package JDSpider.dao;

/**
 * Created by lenovo on 2017/3/27.
 */
public class DBconfiguration {
    //jdbc四大配置参数
    public static final String driverClassName="com.mysql.jdbc.Driver";
    public static final String url="jdbc:mysql://localhost:3306/jdspider";
    public static final String username="root";
    public static final String password="l19921016";

}
